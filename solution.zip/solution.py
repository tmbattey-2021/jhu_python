#list of value counts
finallist = []

#list to track values that have been processed
itemlist = []

#initialize counters
counta = 0
countb = 0

#open file b for processing and leave open to allow for processing of both a and b files
fileb = open("b.csv", "r")
mylistb = fileb.read().splitlines()
mylistb.sort()

#process entire file a
#add each item to output file once counts for a and b are calculated
with open("a.csv") as filea:
    mylista = filea.read().splitlines()
    mylista.sort()
    for item in mylista[:-1]:
        if item in itemlist:
            continue
        else:
            counta = mylista.count(item)
            countb = mylistb.count(item)
            finallist.append([item, counta, countb])
            itemlist.append(item)


counta = 0
countb = 0

#process each item in file b.  Check to see if value already processed before counting.
for item in mylistb[:-1]:
    if item in itemlist:
        continue
    else:
        counta = 0
        countb = mylistb.count(item)
        finallist.append([item, counta, countb])
        itemlist.append(item)
 


fileb.close()

#use csv module to simplify logic
import csv

header = ["id", "a", "b"]
x = sorted(finallist)
data = x

with open("output.csv", "w", newline = '') as f:
    writer = csv.writer(f, delimiter='\t')

    writer.writerow(header)

    writer.writerows(data)